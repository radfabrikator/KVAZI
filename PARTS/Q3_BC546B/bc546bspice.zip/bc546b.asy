Version 4
SymbolType BLOCK
LINE Normal -16 32 -16 -32
LINE Normal -16 0 -32 0
LINE Normal 32 -48 -16 -16
LINE Normal 9 33 -16 16
LINE Normal 13 27 9 33
LINE Normal 32 48 13 27
LINE Normal 5 39 32 48
LINE Normal 9 33 5 39
WINDOW 0 32 -16 Left 2
WINDOW 3 32 16 Left 2
WINDOW 39 0 80 Top 2
SYMATTR Value BC546B
SYMATTR SpiceLine Vceo=65 Vcbo=80 Vebo=5 Ic=100m hfe=450 Ices=.2n Vbe=580m ft=300Meg Ccbo=3.5p Cebo=9p Rc=1 Rb=.1 Re=.1 Eg=1.11 Xti=3
SYMATTR Prefix X
SYMATTR ModelFile .\bc546c_spice.lib
PIN 32 -48 LEFT 8
PINATTR PinName C
PINATTR SpiceOrder 1
PIN -32 0 RIGHT 8
PINATTR PinName B
PINATTR SpiceOrder 2
PIN 32 48 LEFT 8
PINATTR PinName E
PINATTR SpiceOrder 3
